// دالة لعرض التاريخ الحالي
function updateDate() {
    const now = new Date();
    const options = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        weekday: 'long'
    };
    const dateElements = document.querySelectorAll('#current-date');
    
    dateElements.forEach(element => {
        element.textContent = now.toLocaleDateString('ar-SA', options);
    });
}

// دالة لتحديث حالة النظام
function updateSystemStatus() {
    // يمكن استبدالها ببيانات حقيقية من API
    const statusElements = document.querySelectorAll('.status-item');
    
    statusElements.forEach(item => {
        if (item.classList.contains('online')) {
            item.innerHTML = `<i class="fas fa-check-circle"></i><span>كل الأنظمة تعمل</span>`;
        } else if (item.classList.contains('cameras')) {
            item.innerHTML = `<i class="fas fa-video"></i><span>${Math.floor(Math.random() * 5) + 56}/60 كاميرا نشطة</span>`;
        } else if (item.classList.contains('storage')) {
            item.innerHTML = `<i class="fas fa-database"></i><span>${Math.floor(Math.random() * 5) + 75}% سعة التخزين</span>`;
        }
    });
}

// تهيئة الصفحة
document.addEventListener('DOMContentLoaded', function() {
    updateDate();
    updateSystemStatus();
    
    // تحديث البيانات كل 30 ثانية
    setInterval(() => {
        updateSystemStatus();
    }, 30000);
    
    // إضافة تأثيرات للتنبيهات
    const alertBadges = document.querySelectorAll('.alert-badge');
    alertBadges.forEach(badge => {
        badge.addEventListener('click', function() {
            alert('سيتم عرض قائمة التنبيهات');
        });
    });
});