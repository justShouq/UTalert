from flask import Flask, request, jsonify
from PIL import Image
import io
import base64
from ultralytics import YOLO

app = Flask(__name__)

# تحميل النموذج مباشرة باستخدام مكتبة ultralytics
model = YOLO("best (3).pt")  # تأكد أن الاسم مطابق تمامًا

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        image_data = data['image'].split(",")[1]
        image = Image.open(io.BytesIO(base64.b64decode(image_data))).convert("RGB")

        results = model(image)
        predictions = results[0].boxes.data.cpu().tolist()

        return jsonify(predictions)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)