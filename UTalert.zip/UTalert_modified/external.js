// بيانات نموذجية للبوابات والكاميرات
const gatesData = {
    'main-gate': {
        name: 'البوابة الرئيسية',
        image: 'images/main-gate.jpg',
        cameras: ['كاميرا المدخل', 'كاميرا الساحة', 'كاميرا الحرس']
    },
    'north-gate': {
        name: 'بوابة الشمال',
        image: 'images/north-gate.jpg',
        cameras: ['كاميرا المدخل الشمالي', 'كاميرا الزاوية']
    },
    'south-gate': {
        name: 'بوابة الجنوب',
        image: 'images/south-gate.jpg',
        cameras: ['كاميرا المدخل الجنوبي']
    },
    'east-gate': {
        name: 'بوابة الشرق',
        image: 'images/east-gate.jpg',
        cameras: ['كاميرا المدخل الشرقي', 'كاميرا موقف السيارات']
    },
    'west-gate': {
        name: 'بوابة الغرب',
        image: 'images/west-gate.jpg',
        cameras: ['كاميرا المدخل الغربي', 'كاميرا المخزن']
    }
};

// عرض التاريخ الحالي
function updateDate() {
    const now = new Date();
    const options = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        weekday: 'long'
    };
    document.getElementById('current-date').textContent = 
        now.toLocaleDateString('ar-SA', options);
}

// عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    updateDate();
    
    const gateSelect = document.getElementById('gate-select');
    const gateImage = document.getElementById('gate-image');
    const currentGateName = document.getElementById('current-gate-name');
    const gateCamerasGrid = document.getElementById('gate-cameras-grid');

    // عند تغيير البوابة
    gateSelect.addEventListener('change', function() {
        const selectedGate = this.value;
        
        if (selectedGate) {
            const gate = gatesData[selectedGate];
            
            gateImage.src = gate.image;
            gateImage.alt = `صورة ${gate.name}`;
            
            currentGateName.textContent = `البوابة: ${gate.name}`;
            
            updateGateCamerasList(gate.cameras);
        } else {
            resetGateDisplay();
        }
    });

    // تحديث قائمة الكاميرات
    function updateGateCamerasList(cameras) {
        gateCamerasGrid.innerHTML = '';
        
        if (cameras.length === 0) {
            gateCamerasGrid.innerHTML = '<div class="no-cameras">لا توجد كاميرات في هذه البوابة</div>';
            return;
        }
        
        cameras.forEach(camera => {
            const cameraItem = document.createElement('div');
            cameraItem.className = 'camera-item';
            cameraItem.innerHTML = `
                <i class="fas fa-video"></i>
                <span>${camera}</span>
            `;
            
            cameraItem.addEventListener('click', function() {
                alert(`جارٍ تحميل عرض ${camera}`);
            });
            
            gateCamerasGrid.appendChild(cameraItem);
        });
    }

    // إعادة تعيين عرض البوابة
    function resetGateDisplay() {
        gateImage.src = 'images/default-gate.png';
        gateImage.alt = 'صورة البوابة الافتراضية';
        currentGateName.textContent = 'البوابة: -';
        gateCamerasGrid.innerHTML = '<div class="no-cameras">اختر بوابة لعرض الكاميرات</div>';
    }
});