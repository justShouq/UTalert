// تهيئة صفحة المراقبة الداخلية
document.addEventListener('DOMContentLoaded', function() {
    // اختيار المبنى
    const buildingSelect = document.getElementById('building-select');
    const floorButtons = document.querySelectorAll('.floor-btn');
    const cameraThumbs = document.querySelectorAll('.camera-thumb');
    
    if (buildingSelect) {
        buildingSelect.addEventListener('change', function() {
            const selectedBuilding = this.value;
            console.log(`تم اختيار المبنى: ${selectedBuilding}`);
            
            // يمكنك هنا جلب بيانات الطوابق والكاميرات حسب المبنى المختار
        });
    }
    
    // اختيار الطابق
    floorButtons.forEach(button => {
        button.addEventListener('click', function() {
            floorButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            console.log(`تم اختيار الطابق: ${this.textContent}`);
            
            // يمكنك هنا جلب بيانات الكاميرات للطابق المختار
        });
    });
    
    // اختيار الكاميرا المصغرة
    cameraThumbs.forEach(thumb => {
        thumb.addEventListener('click', function() {
            cameraThumbs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            console.log(`تم اختيار الكاميرا: ${this.querySelector('span').textContent}`);
            
            // يمكنك هنا عرض الكاميرا المختارة في العرض الكبير
        });
    });
});