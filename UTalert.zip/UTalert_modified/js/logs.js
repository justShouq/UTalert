// تهيئة صفحة السجلات
document.addEventListener('DOMContentLoaded', function() {
    // تهيئة جدول DataTable
    $('#logs-table').DataTable({
        language: {
            url: 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/ar.json'
        },
        ajax: {
            url: 'data/logs.json', // يمكن استبدالها بمصدر بيانات حقيقي
            dataSrc: ''
        },
        columns: [
            { data: 'datetime' },
            { data: 'type' },
            { data: 'description' },
            { data: 'source' },
            { 
                data: 'status',
                render: function(data, type, row) {
                    let statusClass = '';
                    if (data === 'نشط') statusClass = 'status-active';
                    else if (data === 'تحذير') statusClass = 'status-warning';
                    else if (data === 'حرج') statusClass = 'status-critical';
                    
                    return `<span class="status-badge ${statusClass}">${data}</span>`;
                }
            },
            {
                data: null,
                render: function(data, type, row) {
                    return `<button class="view-log-btn"><i class="fas fa-eye"></i> عرض</button>`;
                }
            }
        ],
        responsive: true,
        order: [[0, 'desc']]
    });
    
    // فلترة السجلات
    $('.filter-btn').click(function() {
        const type = $('#log-type').val();
        const date = $('#log-date').val();
        const search = $('#log-search').val();
        
        // تطبيق الفلتر على الجدول
        const table = $('#logs-table').DataTable();
        table.search(search).draw();
        
        console.log('تم تطبيق الفلتر:', { type, date, search });
    });
    
    // إعادة تعيين الفلتر
    $('.reset-btn').click(function() {
        $('#log-type').val('');
        $('#log-date').val('');
        $('#log-search').val('');
        
        const table = $('#logs-table').DataTable();
        table.search('').draw();
    });
});