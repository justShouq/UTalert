// بيانات نموذجية للمباني والطوابق والكاميرات
const buildingsData = {
    'main-building': {
        name: 'المبنى الرئيسي',
        floors: {
            'floor-1': {
                name: 'الطابق الأول',
                image: 'images/main-building-floor1.jpg',
                cameras: ['كاميرا 1', 'كاميرا 2', 'كاميرا 3', 'كاميرا 4']
            },
            'floor-2': {
                name: 'الطابق الثاني',
                image: 'images/main-building-floor2.jpg',
                cameras: ['كاميرا 5', 'كاميرا 6']
            }
        }
    },
    'training-center': {
        name: 'مركز التدريب',
        floors: {
            'floor-1': {
                name: 'الطابق الأرضي',
                image: 'images/training-center-floor0.jpg',
                cameras: ['كاميرا 7', 'كاميرا 8']
            }
        }
    },
    'office-building': {
        name: 'مبنى المكاتب',
        floors: {
            'floor-1': {
                name: 'طابق المكاتب',
                image: 'images/office-building-floor1.jpg',
                cameras: ['كاميرا 9', 'كاميرا 10', 'كاميرا 11']
            }
        }
    }
};

// عرض التاريخ الحالي
function updateDate() {
    const now = new Date();
    const options = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        weekday: 'long'
    };
    document.getElementById('current-date').textContent = 
        now.toLocaleDateString('ar-SA', options);
}

// عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    updateDate();
    
    const buildingSelect = document.getElementById('building-select');
    const floorSelect = document.getElementById('floor-select');
    const floorImage = document.getElementById('floor-image');
    const currentFloorName = document.getElementById('current-floor-name');
    const camerasGrid = document.getElementById('cameras-grid');

    // إذا كانت هذه العناصر موجودة (في صفحة المراقبة الداخلية فقط)
    if (buildingSelect && floorSelect) {
        // عند تغيير المبنى
        buildingSelect.addEventListener('change', function() {
            const selectedBuilding = this.value;
            
            floorSelect.innerHTML = '<option value="">اختر الطابق</option>';
            floorSelect.disabled = !selectedBuilding;
            
            if (selectedBuilding) {
                const building = buildingsData[selectedBuilding];
                
                Object.keys(building.floors).forEach(floorKey => {
                    const floor = building.floors[floorKey];
                    const option = document.createElement('option');
                    option.value = floorKey;
                    option.textContent = floor.name;
                    floorSelect.appendChild(option);
                });
            }
            
            resetFloorDisplay();
        });

        // عند تغيير الطابق
        floorSelect.addEventListener('change', function() {
            const selectedBuilding = buildingSelect.value;
            const selectedFloor = this.value;
            
            if (selectedBuilding && selectedFloor) {
                const building = buildingsData[selectedBuilding];
                const floor = building.floors[selectedFloor];
                
                floorImage.src = floor.image;
                floorImage.alt = `صورة ${floor.name}`;
                
                currentFloorName.textContent = `الطابق: ${floor.name}`;
                
                updateCamerasList(floor.cameras);
            } else {
                resetFloorDisplay();
            }
        });

        // تحديث قائمة الكاميرات
        function updateCamerasList(cameras) {
            camerasGrid.innerHTML = '';
            
            if (cameras.length === 0) {
                camerasGrid.innerHTML = '<div class="no-cameras">لا توجد كاميرات في هذا الطابق</div>';
                return;
            }
            
            cameras.forEach(camera => {
                const cameraItem = document.createElement('div');
                cameraItem.className = 'camera-item';
                cameraItem.innerHTML = `
                    <i class="fas fa-video"></i>
                    <span>${camera}</span>
                `;
                
                cameraItem.addEventListener('click', function() {
                    alert(`جارٍ تحميل عرض ${camera}`);
                });
                
                camerasGrid.appendChild(cameraItem);
            });
        }

        // إعادة تعيين عرض الطابق
        function resetFloorDisplay() {
            floorImage.src = 'images/default-floor.png';
            floorImage.alt = 'صورة الطابق الافتراضية';
            currentFloorName.textContent = 'الطابق: -';
            camerasGrid.innerHTML = '<div class="no-cameras">اختر مبنى وطابقًا لعرض الكاميرات</div>';
        }
    }
});